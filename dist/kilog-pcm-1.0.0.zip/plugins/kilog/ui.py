from __future__ import annotations

from pathlib import Path
import tkinter as tk
from tkinter import messagebox

from .recorder import Recorder, RecorderConfig, RecorderError


BG = "#063D2C"
PANEL = "#0A4A36"
ORANGE = "#F5A11A"
ORANGE_ACTIVE = "#FFB63E"
CREAM = "#F7F2E8"
MUTED = "#A8C6B8"
RED = "#F26B5E"


class KiLogWindow:
    POLL_MS = 160

    def __init__(self, root: tk.Tk, recorder: Recorder, asset_directory: Path):
        self.root = root
        self.recorder = recorder
        self.asset_directory = asset_directory
        self.icon_image: tk.PhotoImage | None = None
        self.status_job: str | None = None

        root.title("KiLog — PCB operation recorder")
        root.configure(bg=BG)
        root.resizable(False, False)
        root.protocol("WM_DELETE_WINDOW", self._close)
        self._build()
        self._set_controls(False)
        self._center()
        self._schedule_poll()

    def _build(self) -> None:
        outer = tk.Frame(self.root, bg=BG, padx=24, pady=20)
        outer.grid(row=0, column=0)

        header = tk.Frame(outer, bg=BG)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 18))
        icon_path = self.asset_directory / "icon-ui-64.png"
        if icon_path.exists():
            self.icon_image = tk.PhotoImage(file=str(icon_path))
            tk.Label(header, image=self.icon_image, bg=BG).grid(row=0, column=0, rowspan=2, padx=(0, 12))
        tk.Label(
            header,
            text="KiLog",
            bg=BG,
            fg=CREAM,
            font=("Segoe UI Semibold", 20),
        ).grid(row=0, column=1, sticky="w")
        tk.Label(
            header,
            text="LIVE PCB CHANGE JOURNAL",
            bg=BG,
            fg=ORANGE,
            font=("Consolas", 8),
        ).grid(row=1, column=1, sticky="w")

        form = tk.Frame(outer, bg=PANEL, padx=16, pady=14, highlightthickness=1, highlightbackground="#176A50")
        form.grid(row=1, column=0, sticky="ew")
        tk.Label(form, text="目标 PCB 文件名", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).grid(
            row=0, column=0, sticky="w"
        )
        tk.Label(form, text="目标 Log 文件名", bg=PANEL, fg=MUTED, font=("Segoe UI", 9)).grid(
            row=0, column=1, sticky="w", padx=(12, 0)
        )
        self.pcb_name = tk.StringVar(value="ref")
        self.log_name = tk.StringVar(value="log")
        self.pcb_entry = self._entry(form, self.pcb_name)
        self.pcb_entry.grid(row=1, column=0, pady=(5, 0))
        self.log_entry = self._entry(form, self.log_name)
        self.log_entry.grid(row=1, column=1, padx=(12, 0), pady=(5, 0))

        buttons = tk.Frame(outer, bg=BG)
        buttons.grid(row=2, column=0, pady=(18, 12), sticky="ew")
        self.start_button = self._button(buttons, "start", self._start, primary=True)
        self.note_button = self._button(buttons, "note", self._note)
        self.undo_button = self._button(buttons, "undo", self._undo)
        self.end_button = self._button(buttons, "end", self._end)
        for column, button in enumerate(
            (self.start_button, self.note_button, self.undo_button, self.end_button)
        ):
            button.grid(row=0, column=column, padx=(0 if column == 0 else 8, 0), sticky="ew")
            buttons.grid_columnconfigure(column, weight=1, uniform="actions")

        status = tk.Frame(outer, bg=BG)
        status.grid(row=3, column=0, sticky="ew")
        self.status_dot = tk.Canvas(status, width=10, height=10, bg=BG, highlightthickness=0)
        self.status_dot.grid(row=0, column=0, padx=(0, 7))
        self.dot_id = self.status_dot.create_oval(1, 1, 9, 9, fill=MUTED, outline="")
        self.status_text = tk.StringVar(value="就绪 — 点击 start 开始记录")
        tk.Label(
            status,
            textvariable=self.status_text,
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
            width=48,
        ).grid(row=0, column=1, sticky="w")
        self.counter_text = tk.StringVar(value="0 changes")
        tk.Label(
            status,
            textvariable=self.counter_text,
            bg=BG,
            fg=ORANGE,
            font=("Consolas", 8),
        ).grid(row=0, column=2, sticky="e")

        output = self.recorder.adapter.output_directory
        tk.Label(
            outer,
            text=f"输出目录  {output}",
            bg=BG,
            fg="#6E9C87",
            font=("Consolas", 8),
            anchor="w",
        ).grid(row=4, column=0, sticky="w", pady=(8, 0))

    @staticmethod
    def _entry(parent: tk.Widget, variable: tk.StringVar) -> tk.Entry:
        return tk.Entry(
            parent,
            textvariable=variable,
            width=24,
            bg="#052F23",
            fg=CREAM,
            insertbackground=ORANGE,
            relief="flat",
            highlightthickness=1,
            highlightbackground="#27735A",
            highlightcolor=ORANGE,
            font=("Consolas", 10),
        )

    @staticmethod
    def _button(parent: tk.Widget, text: str, command, primary: bool = False) -> tk.Button:
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=ORANGE if primary else PANEL,
            fg=BG if primary else CREAM,
            activebackground=ORANGE_ACTIVE,
            activeforeground=BG,
            disabledforeground="#668A79",
            relief="flat",
            bd=0,
            padx=18,
            pady=9,
            cursor="hand2",
            font=("Segoe UI Semibold", 10),
        )

    def _center(self) -> None:
        self.root.update_idletasks()
        width = self.root.winfo_reqwidth()
        height = self.root.winfo_reqheight()
        x = (self.root.winfo_screenwidth() - width) // 2
        y = (self.root.winfo_screenheight() - height) // 3
        self.root.geometry(f"{width}x{height}+{x}+{y}")

    def _set_controls(self, running: bool) -> None:
        self.start_button.configure(state="disabled" if running else "normal")
        state = "normal" if running else "disabled"
        self.note_button.configure(state=state)
        self.undo_button.configure(state=state)
        self.end_button.configure(state=state)
        entry_state = "disabled" if running else "normal"
        self.pcb_entry.configure(state=entry_state)
        self.log_entry.configure(state=entry_state)

    def _status(self, text: str, color: str = MUTED) -> None:
        self.status_text.set(text)
        self.status_dot.itemconfigure(self.dot_id, fill=color)
        self.counter_text.set(f"{self.recorder.event_count} changes")

    def _run_action(self, action) -> None:
        try:
            action()
        except Exception as exc:
            self._status(str(exc), RED)
            messagebox.showerror("KiLog", str(exc), parent=self.root)

    def _start(self) -> None:
        def action() -> None:
            self.recorder.start(
                RecorderConfig(pcb_stem=self.pcb_name.get(), log_stem=self.log_name.get())
            )
            self._set_controls(True)
            self._status("记录中 — 监听未保存 PCB 内存状态", ORANGE)

        self._run_action(action)

    def _note(self) -> None:
        def action() -> None:
            path = self.recorder.note()
            self._status(f"已保存快照 {path.name}", ORANGE)

        self._run_action(action)

    def _undo(self) -> None:
        def action() -> None:
            path, strategy = self.recorder.undo()
            label = "KiCad 原生撤销" if strategy == "native" else "对象快照恢复"
            self._status(f"已撤销并删除 {path.name} · {label}", ORANGE)

        self._run_action(action)

    def _end(self) -> None:
        def action() -> None:
            event = self.recorder.end()
            self._set_controls(False)
            suffix = "，最后变化已写入" if event else ""
            self._status(f"记录已结束{suffix}", MUTED)

        self._run_action(action)

    def _schedule_poll(self) -> None:
        self.status_job = self.root.after(self.POLL_MS, self._poll)

    def _poll(self) -> None:
        try:
            if self.recorder.recording:
                event = self.recorder.poll()
                if event:
                    self._status(f"已写入 log #{event['sequence']:06d}", ORANGE)
        except Exception as exc:
            # Busy responses are normal while the router or an interactive move owns the editor.
            lowered = str(exc).lower()
            if "busy" in lowered or "timeout" in lowered:
                self._status("等待 KiCad 完成交互操作…", ORANGE)
            else:
                self._status(f"监听暂时失败：{exc}", RED)
        finally:
            self._schedule_poll()

    def _close(self) -> None:
        if self.status_job is not None:
            self.root.after_cancel(self.status_job)
        if self.recorder.recording:
            try:
                self.recorder.end()
            except Exception as exc:
                if not messagebox.askyesno(
                    "KiLog",
                    f"最后变化写入失败：{exc}\n仍要关闭吗？",
                    parent=self.root,
                ):
                    self._schedule_poll()
                    return
        self.root.destroy()

